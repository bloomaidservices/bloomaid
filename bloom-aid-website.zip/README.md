# 🌿 Bloom Aid

Bloom Aid is a business website dedicated to professional plant care, natural fertilizers, and gardening services.

## 🪴 Pages
- **Home** – Overview of Bloom Aid services.
- **About** – About our mission and team.
- **Services** – Gardening and plant care solutions.
- **Products** – Natural and organic fertilizers.
- **Contact** – Get in touch with us.

## 💻 Tech Stack
- HTML5  
- CSS3  

## 📄 License
© 2025 Bloom Aid. All rights reserved.
